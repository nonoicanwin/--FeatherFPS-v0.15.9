# FeatherFPS

Lightweight native Android screen recorder with a cyan/neon interface and configurable 60, 90, 120, or 144 FPS target, 720p/1080p/native resolution, 4/8/12/20 Mbps H.264 bitrate, optional microphone audio, and MP4 output under `Movies/FeatherFPS`.

## Compatibility
- Minimum Android: 10 (API 29)
- Target/compile SDK: Android 16 (API 36)
- UI uses native Android widgets and has no third-party runtime dependencies.

## Important FPS limitation
The FPS menu configures the encoder target. It cannot force Android's virtual display to generate new frames that the device does not provide. Actual recorded FPS depends on display refresh rate, MediaProjection, system load, and encoder capabilities. 90/120/144 options may be capped, unstable, or unsupported by some devices; higher targets usually work best with lower resolution and bitrate.

## Build
Open this project in Android Studio with Android SDK Platform 36 installed, or use the included GitHub Actions workflow. The workflow produces a debug APK artifact named `FeatherFPS-APK`.
