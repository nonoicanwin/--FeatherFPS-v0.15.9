package com.meadow.featherfps

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class RecorderService : Service() {
    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var display: VirtualDisplay? = null
    private var outputUri: Uri? = null
    private var outputFile: ParcelFileDescriptor? = null
    private var isRecording = false
    private var isStopping = false
    private var activeFps = 60

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRecording()
            return START_NOT_STICKY
        }
        if (isRecording) return START_NOT_STICKY

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        activeFps = (intent?.getIntExtra(EXTRA_FPS, 60) ?: 60).coerceIn(30, 144)
        val resolution = intent?.getIntExtra(EXTRA_RESOLUTION, 720) ?: 720
        val bitrate = (intent?.getIntExtra(EXTRA_BITRATE, 8_000_000) ?: 8_000_000).coerceIn(2_000_000, 30_000_000)
        val useMic = intent?.getBooleanExtra(EXTRA_MIC, false) ?: false

        createNotificationChannel()
        val foregroundTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
            if (useMic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        try {
            startForeground(NOTIFICATION_ID, buildNotification(activeFps), foregroundTypes)
        } catch (failure: Exception) {
            Log.e(TAG, "Unable to enter foreground", failure)
            stopSelf(startId)
            return START_NOT_STICKY
        }

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            publishState(false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
            return START_NOT_STICKY
        }

        try {
            beginRecording(resultCode, resultData, resolution, bitrate, useMic)
        } catch (failure: Exception) {
            Log.e(TAG, "Could not start screen recording", failure)
            stopRecording()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun beginRecording(resultCode: Int, resultData: Intent, resolution: Int, bitrate: Int, useMic: Boolean) {
        val metrics = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val screenWidth = max(2, metrics.widthPixels)
        val screenHeight = max(2, metrics.heightPixels)
        val shortSide = min(screenWidth, screenHeight).toFloat()
        val scale = when (resolution) {
            720 -> 720f / shortSide
            1080 -> 1080f / shortSide
            else -> 1f
        }
        val outWidth = (screenWidth * scale).toInt().coerceAtLeast(2) and -2
        val outHeight = (screenHeight * scale).toInt().coerceAtLeast(2) and -2
        val safeBitrate = when {
            outWidth * outHeight >= 2_500_000 && activeFps >= 120 -> min(bitrate, 20_000_000)
            else -> bitrate
        }

        outputUri = createOutputUri()
        outputFile = contentResolver.openFileDescriptor(outputUri!!, "w")
            ?: throw IllegalStateException("Could not open output video")

        val mr = MediaRecorder()
        recorder = mr
        if (useMic) mr.setAudioSource(MediaRecorder.AudioSource.MIC)
        mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        mr.setOutputFile(outputFile!!.fileDescriptor)
        mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        mr.setVideoSize(outWidth, outHeight)
        mr.setVideoFrameRate(activeFps)
        mr.setVideoEncodingBitRate(safeBitrate)
        if (useMic) {
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioSamplingRate(44_100)
            mr.setAudioEncodingBitRate(128_000)
        }
        mr.prepare()

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, resultData)
            ?: throw IllegalStateException("Screen-capture permission was not granted")
        val callback = object : MediaProjection.Callback() {
            override fun onStop() { stopRecording() }
        }
        projectionCallback = callback
        projection!!.registerCallback(callback, Handler(Looper.getMainLooper()))
        display = projection!!.createVirtualDisplay(
            "FeatherFPS-Screen",
            outWidth,
            outHeight,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            mr.surface,
            null,
            null
        ) ?: throw IllegalStateException("Could not create virtual display")

        mr.start()
        isRecording = true
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(PREF_ACTIVE_FPS, activeFps).apply()
        publishState(true)
    }

    private fun createOutputUri(): Uri {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "FeatherFPS_$timestamp.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/FeatherFPS")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create a video in Movies/FeatherFPS")
    }

    private fun stopRecording() {
        if (isStopping) return
        isStopping = true
        val wasRecording = isRecording
        isRecording = false
        var validVideo = false
        if (wasRecording) {
            try {
                recorder?.stop()
                validVideo = true
            } catch (failure: Exception) {
                Log.w(TAG, "Recorder stopped before a valid clip was produced", failure)
            }
        }
        try { display?.release() } catch (_: Exception) { }
        display = null
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null

        val currentProjection = projection
        val currentCallback = projectionCallback
        if (currentProjection != null && currentCallback != null) {
            try { currentProjection.unregisterCallback(currentCallback) } catch (_: Exception) { }
        }
        projectionCallback = null
        try { currentProjection?.stop() } catch (_: Exception) { }
        projection = null

        try { outputFile?.close() } catch (_: Exception) { }
        outputFile = null
        outputUri?.let { uri ->
            if (validVideo) {
                val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                try { contentResolver.update(uri, values, null, null) } catch (_: Exception) { }
            } else {
                try { contentResolver.delete(uri, null, null) } catch (_: Exception) { }
            }
        }
        outputUri = null
        publishState(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        isStopping = false
    }

    private fun publishState(running: Boolean) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREF_RECORDING, running).apply()
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName)
            .putExtra(EXTRA_RUNNING, running)
            .putExtra(EXTRA_FPS, activeFps))
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "FeatherFPS recording", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows while FeatherFPS is capturing your screen"
            })
        }
    }

    private fun buildNotification(fps: Int): Notification {
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 11, Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("FeatherFPS is recording")
            .setContentText("$fps FPS target · tap STOP to save your clip")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "STOP", stop)
            .build()
    }

    override fun onDestroy() {
        if ((isRecording || outputUri != null) && !isStopping) stopRecording()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.meadow.featherfps.action.STOP"
        const val ACTION_STATE = "com.meadow.featherfps.action.STATE"
        const val EXTRA_RUNNING = "running"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_FPS = "target_fps"
        const val EXTRA_RESOLUTION = "resolution"
        const val EXTRA_BITRATE = "bitrate"
        const val EXTRA_MIC = "use_mic"
        const val PREFS = "featherfps_state"
        const val PREF_RECORDING = "recording"
        const val PREF_ACTIVE_FPS = "active_fps"
        private const val TAG = "FeatherFPS"
        private const val CHANNEL_ID = "featherfps_recording"
        private const val NOTIFICATION_ID = 6017
    }
}
